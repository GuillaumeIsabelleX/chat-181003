# chat-181003
@!v 181003 Experimentation to master the Socket.io, to observe what it does...


# @!cr Status
* you can -> ENter your name
* Message counting and distribution of the variable thru all connected user
